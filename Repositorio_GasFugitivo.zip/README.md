
# Detección de Gases Fugitivos con UNet 🔍🌫️

Este proyecto implementa una red neuronal convolucional tipo **UNet** para la segmentación de emisiones gaseosas en imágenes industriales, enfocándose en identificar **fugas de gases fugitivos**. Utiliza imágenes reales procesadas y anotadas con clases como cielo, edificio, emisión, etc.

---

## 📁 Contenido del repositorio

- `Segmentacion_Gases_Fugitivos_UNet.ipynb`: Notebook principal de entrenamiento y predicción.
- `data/`: Carpeta recomendada para imágenes y máscaras si son pequeñas. Si pesan más de 100 MB, usar Drive (ver más abajo).
- `README.md`: Este archivo explicativo.

---

## 🧪 Ejecución en Google Colab

Haz clic aquí para abrir el notebook:

[![Abrir en Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/drive/)

> Nota: Deberás montar tu Google Drive y enlazar la ruta de tu dataset para ejecutar el notebook correctamente.

---

## 📂 Acceso a los datos

Debido al tamaño de las imágenes y máscaras, los datos se encuentran en Google Drive:

📎 **[Dataset en Drive](https://drive.google.com/drive/folders/TU_ENLACE_AQUI)**

Organiza tus archivos como:
```
/content/drive/MyDrive/ProyectoGases/
    ├── Imagenes/
    └── Mascaras/
```

---

## 🛠️ Librerías requeridas

- TensorFlow / Keras
- OpenCV
- Numpy
- Matplotlib
- Scikit-learn

Instálalas con:
```bash
pip install tensorflow opencv-python scikit-learn matplotlib
```

---

## 🧠 Arquitectura del modelo

El modelo utiliza una arquitectura **UNet** con capas de codificación y decodificación, ideal para tareas de segmentación semántica. El objetivo es clasificar píxeles que representan gases fugitivos en diferentes condiciones de luz.

---

## 📸 Ejemplos de detección

El modelo fue probado en imágenes con condiciones:
- Diurnas ☀️
- Tarde 🌇
- Vespertinas 🌆

Detecta correctamente el contorno y proporción de emisiones, mostrando el resultado con mapas de calor y contornos segmentados.

---

## 📬 Contacto

Este proyecto fue desarrollado con fines académicos y de investigación. Para más información, contáctame vía GitHub o correo.
